

public /*@ nullable_by_default @*/ class Proofview  {

  public void update(Set<Theorem> theorems){}
}


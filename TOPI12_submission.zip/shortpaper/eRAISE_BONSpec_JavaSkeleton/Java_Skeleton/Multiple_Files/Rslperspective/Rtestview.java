

public /*@ nullable_by_default @*/ class Rtestview  {

  public void update(Set<Testresult> restResults){}
}




public /*@ nullable_by_default @*/ class Problems  {

  public void update(Set<Problem> problems){}
}




public /*@ nullable_by_default @*/ class Smlcompiler  {

  public /*@ pure @*/ List<Char> compile(Entity entity, /*@ non_null @*/ Context context){}
}




public /*@ nullable_by_default @*/ class Smltranslator  {

  public void translate(/*@ non_null @*/ Context context){}
}


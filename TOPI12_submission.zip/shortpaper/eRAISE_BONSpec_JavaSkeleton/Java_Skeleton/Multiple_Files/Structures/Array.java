

public /*@ nullable_by_default @*/ class Array  {
}




public /*@ nullable_by_default @*/ class Integer implements Number {
}


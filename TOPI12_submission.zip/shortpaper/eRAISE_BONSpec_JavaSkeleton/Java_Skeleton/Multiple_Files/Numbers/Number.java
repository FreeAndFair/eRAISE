

public /*@ nullable_by_default @*/ class Number implements int {
}


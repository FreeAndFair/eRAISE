

public /*@ nullable_by_default @*/ class Float implements Number {
}


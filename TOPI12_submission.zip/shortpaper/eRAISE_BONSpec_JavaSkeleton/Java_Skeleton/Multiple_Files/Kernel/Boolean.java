

public /*@ nullable_by_default @*/ class Boolean  {
}

